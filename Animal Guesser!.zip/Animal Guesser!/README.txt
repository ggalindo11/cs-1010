GUI Project sec-02 - Group 9

Gabriel Galindo, Leonardo Pahtle Quechol, Jesus Mendoza

# How To
Our game is a simple animal guesser, as the name implies. Simply choose an animal and answer the yes & no questions to see if we can guess your animal with the given prompts.