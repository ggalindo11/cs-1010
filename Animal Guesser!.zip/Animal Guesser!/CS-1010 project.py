import tkinter as tk

# /// Main window GUI \\\ - - - - - - - - - - - - - - - - - - - -
me = tk.Tk()
me.geometry("1200x900")
me.title("Animal Guesser!")
me.config(bg="#567d46", highlightbackground="Orange", highlightthickness=15)

#### but1 = kangaroo, but2 = octopus, but3 = zebra, but4 = eagle, but5 = snake, but6 = elephant

img1 = tk.PhotoImage(file="kangaroo.png")
img2 = tk.PhotoImage(file="octopus.png")
img3 = tk.PhotoImage(file="zebra.png")
img4 = tk.PhotoImage(file="eagle.png")
img5 = tk.PhotoImage(file="snake.png")
img6 = tk.PhotoImage(file="elephant.png")

# /// Question Window GUI \\\ - - - - - - - - - - - - - - - - - - - -
def newWin():
    me.iconify()
    nwin = tk.Toplevel()
    nwin.title("Can We Guess Your Animal?")
    nwin.geometry("800x600")
    nwin.config(bg="#567d46", highlightbackground="Orange", highlightthickness=5)

    imglabel1 = tk.Label(nwin, image=img1, bg="#567d46")
    imglabel1.place(x=8, y=120)

    imglabel5 = tk.Label(nwin, image=img5, bg="#567d46")
    imglabel5.place(x=530, y=120)

    # /// Question & Answers \\\ - - - - - - - - - - - - - - - - - - - -
    def cmdy():
        quest.configure(text="Does your animal have wings?")
        gbut1.configure(command=delay)
        gbut2.configure(command=q1n)

        imglabel1.config(image=img4)

        imglabel5.config(image=img4)

    def cmdn():
        quit()


    def q1n():
        quest.configure(text="Does Your Animal Have Legs?")
        gbut1.config(command=q2y)
        gbut2.configure(command=q4n)

        imglabel1.config(image=img1)

        imglabel5.config(image=img3)


    def delay():
        nwin.iconify()
        testx = quest.configure(text="Your Animal Is a Eagle!", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        testy = nwin.destroy
        testz = tk.Toplevel()
        testz.configure(bg="#567d46", highlightbackground="Orange", highlightthickness=5)
        testz.geometry("800x600")
        testLabel = tk.Label(testz, image=img4, bg="#567d46")
        winlabel = tk.Label(testz, text="We Guess Eagle! Are we Right?", bg='#063606', fg='#f5ef42', font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        winlabel.pack()
        testLabel.pack(fill="both", expand="yes")
        testz.configure(width=256, height=256)


    def q2y():
        quest.configure(text="Does Your Animal Have Only 2 Legs?")
        gbut1.config(command=q3y)
        gbut2.configure(command=q2n)

        imglabel1.config(image=img1)

        imglabel5.config(image=img1)

    def q2n():
        quest.configure(text="Does Your Animal Have Stripes?")
        gbut1.config(command=q4y)
        gbut2.config(command=q3n)

        imglabel1.config(image=img3)

        imglabel5.config(image=img3)


    def q3y():
        #Kangaroo
        nwin.iconify()
        testx = quest.configure(text="Your Animal Is a Kangaroo!", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        testy = nwin.destroy
        testz = tk.Toplevel()
        testz.configure(bg="#567d46", highlightbackground="Orange", highlightthickness=5)
        testz.geometry("800x600")
        testLabel = tk.Label(testz, image=img1, bg="#567d46")
        winlabel = tk.Label(testz, text="We Guess Kangaroo! Are we Right?", bg='#063606', fg='#f5ef42', font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        winlabel.pack()
        testLabel.pack(fill="both", expand="yes")
        testz.configure(width=256, height=256)


    def q4y():
        #Zebra win
        nwin.iconify()
        testx = quest.configure(text="Your Animal Is a Zebra!", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        testy = nwin.destroy
        testz = tk.Toplevel()
        testz.configure(bg="#567d46", highlightbackground="Orange", highlightthickness=5)
        testz.geometry("800x600")
        testLabel = tk.Label(testz, image=img3, bg="#567d46")
        winlabel = tk.Label(testz, text="We Guess Zebra! Are we Right?", bg='#063606', fg='#f5ef42',
                            font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        winlabel.pack()
        testLabel.pack(fill="both", expand="yes")
        testz.configure(width=256, height=256)


    def q3n():
        quest.configure(text="Is Your Animal REALLY Big?")
        gbut1.config(command=q5y)
        gbut2.config(command=q4n)

        imglabel1.config(image=img6)

        imglabel5.config(image=img6)

    def q5y():
        #Elephant wins
        nwin.iconify()
        testx = quest.configure(text="Your Animal Is an Elephant!", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        testy = nwin.destroy
        testz = tk.Toplevel()
        testz.configure(bg="#567d46", highlightbackground="Orange", highlightthickness=5)
        testz.geometry("800x600")
        testLabel = tk.Label(testz, image=img6, bg="#567d46")
        winlabel = tk.Label(testz, text="We Guess Elephant! Are we Right?", bg='#063606', fg='#f5ef42',
                            font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        winlabel.pack()
        testLabel.pack(fill="both", expand="yes")
        testz.configure(width=256, height=256)


    def q4n():
        quest.configure(text="Does Your Animal Have 8 Limbs?")
        gbut1.config(command=q6y)
        gbut2.config(command=q5n)

        imglabel1.config(image=img2)

        imglabel5.config(image=img2)

    def q6y():
        #Ocotopus wins
        nwin.iconify()
        testx = quest.configure(text="Your Animal Is an Ocotopus!", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        testy = nwin.destroy
        testz = tk.Toplevel()
        testz.configure(bg="#567d46", highlightbackground="Orange", highlightthickness=5)
        testz.geometry("800x600")
        testLabel = tk.Label(testz, image=img2, bg="#567d46")
        winlabel = tk.Label(testz, text="We Guess Ocotopus! Are we Right?", bg='#063606', fg='#f5ef42',
                            font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        winlabel.pack()
        testLabel.pack(fill="both", expand="yes")
        testz.configure(width=256, height=256)


    def q5n():
        quest.configure(text="Does Your Animal Slither?")
        gbut1.config(command=q7y)
        gbut2.config(command=q6n)

        imglabel1.config(image=img5)
        imglabel5.config(image=img5)

    def q7y():
        #Snake wins
        nwin.iconify()
        testx = quest.configure(text="Your Animal Is a Snake!", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        testy = nwin.destroy
        testz = tk.Toplevel()
        testz.configure(bg="#567d46", highlightbackground="Orange", highlightthickness=5)
        testz.geometry("800x600")
        testLabel = tk.Label(testz, image=img5, bg="#567d46")
        winlabel = tk.Label(testz, text="We Guess Snake! Are we Right?", bg='#063606', fg='#f5ef42',
                            font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        winlabel.pack()
        testLabel.pack(fill="both", expand="yes")
        testz.configure(width=256, height=256)


    def q6n():
        quest.configure(text="You Didn't Pick An Animal. Try Again?", highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
        gbut1.config(command=cmdy)
        gbut2.config(command=cmdn)

    # /// Starter Question & Input Buttons \\\ - - - - - - - - - - - - - - - - - - - -
    quest = tk.Label(nwin, text="Are you Ready?", bg='#063606', fg='#f5ef42', font=("bold", 35), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10)
    quest.pack()

    gbut1 = tk.Button(nwin, text='Yes', width=5, height=1, bg="#063606", fg="#6666ff", font=("bold", 35), command=cmdy, highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10)
    gbut1.place(x=335, y=200)

    gbut2 = tk.Button(nwin, text='No', width=5, height=1, bg="#063606", fg="#6666ff", font=("bold", 35), command=cmdn, highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10)
    gbut2.place(x=335, y=350)

# /// Picture Select Buttons & Label \\\ - - - - - - - - - - - - - - - - - - - -
but1 = tk.Button(me, image=img1, width=256, height=256, bg="#ff6666", highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10, command=newWin)
but1.grid(row=0, column=0, padx=40, pady=70)

but2 = tk.Button(me, image=img2, width=256, height=256, bg="#ff6666", highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10, command=newWin)
but2.grid(row=0, column=1, padx=40, pady=70)

but3 = tk.Button(me, image=img3, width=256, height=256, bg="#ff6666", highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10, command=newWin)
but3.grid(row=0, column=2, padx=40, pady=70)

but4 = tk.Button(me, image=img4, width=256, height=256, bg="#ff6666", highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10, command=newWin)
but4.grid(row=2, column=0, padx=40, pady=30)

but5 = tk.Button(me, image=img5, width=256, height=256, bg="#ff6666", highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10, command=newWin)
but5.grid(row=2, column=1, padx=40, pady=30)

but6 = tk.Button(me, image=img6, width=256, height=256, bg="#ff6666", highlightthickness=1, highlightcolor="blue", highlightbackground="blue", borderwidth=10, command=newWin)
but6.grid(row=2, column=2, padx=40, pady=30)

lbl1 = tk.Label(me, text="Choose Your Animal!", bg="#063606", fg="#f5ef42", font=("bold", 30), highlightthickness=1, highlightcolor="Yellow", highlightbackground="Yellow", borderwidth=10,)
lbl1.grid(row=1, column=1, padx=40, pady=20)

me.mainloop()
